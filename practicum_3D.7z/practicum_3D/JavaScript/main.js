document.addEventListener("DOMContentLoaded", function() {
    const width = 600;
    const height = 600;      
    const svg = d3.select("svg")
       .attr("width", width)
	   .attr("height", height) ;

    //let pict = drawSmile(svg);
    //pict.attr("transform", "translate(200, 200)");
    //let pict1 = drawSmile(svg); 
    //pict1.attr("transform", `translate(400, 400) scale(1.5, 1.5) rotate(180)`);

    document.getElementById("bt_draw").onclick = function() {
        if (document.getElementById("cb_animation")) { if (!document.getElementById("cb_animation").checked) draw(document.getElementById("setting")); } 
        else draw(document.getElementById("setting"));
    };
    document.getElementById("bt_clear").onclick = function() {
        clear(svg);
    };
    document.getElementById("animation").onchange = function() {
        animation_change();
    };
});

let draw = (dataForm) => {
	const svg = d3.select("svg");
    let pict = drawSmile(svg);
    pict.attr("transform", `translate(${dataForm.cx.value}, ${dataForm.cy.value}) scale(${dataForm.cscalex.value}, ${dataForm.cscaley.value}) rotate(${dataForm.crotate.value})`);
};

let clear = (svg) => {
    svg.selectAll('*').remove()
};

let runAnimation = (dataForm) => {
	const svg = d3.select("svg")
    let pict = drawSmile(svg);
    if (!document.getElementById("cb_animation").checked) {
        let style = d3.easeLinear;
        if (document.getElementById("sl_animation").value == 'elastic') {
            style = d3.easeElastic;
        }
        if (document.getElementById("sl_animation").value == 'bounce') {
            style = d3.easeBounce;
        }
        pict.attr("transform", `translate(${dataForm.cx.value}, ${dataForm.cy.value}) scale(${dataForm.cscalex.value}, ${dataForm.cscaley.value}) rotate(${dataForm.crotate.value})`)
            .transition()
            .duration(6000)
            .ease(style)
            .attr("transform", `translate(${dataForm.fx.value}, ${dataForm.fy.value}) scale(${dataForm.fscalex.value}, ${dataForm.fscaley.value}) rotate(${dataForm.frotate.value})`);  

    } else {
        let num = 0;
        if (document.getElementById("sl_animation_kind").value == 'Circle') num = 1;
        let path = drawPath(num);
        let style = d3.easeLinear;
        if (document.getElementById("sl_animation").value == 'elastic') {
            style = d3.easeElastic;
        }
        if (document.getElementById("sl_animation").value == 'bounce') {
            style = d3.easeBounce;
        }	
		pict.transition()
        .ease(style)
        .duration(6000)
        .attrTween('transform', translateAlong(path.node()));
    }
}

function addLabel(newId) {
    let newLabel = document.createElement('label');
    newLabel.setAttribute('for', newId);
    newLabel.textContent = ' до ';
    return newLabel;
}

function addInput(newType, newId, newValue, newMax, newMin) {
    let newInput = document.createElement('input');
    if (newId == 'fscalex' || newId == 'fscaley') newInput.step = '0.1';
    if (newType == 'button') {
        newInput.type = newType;
        newInput.id = newId;
        newInput.value = newValue;
        return newInput;
    }
    newInput.type = newType;
    newInput.id = newId;
    newInput.value = newValue;
    newInput.max = newMax;
    newInput.min = newMin;
    return newInput;
}

let kind_animation_change = () => {
    let checkbox = document.getElementById("cb_animation");
    let boldElements = document.getElementsByTagName('b');

    if (checkbox.checked) {
        document.getElementById("animation").disabled = true;
        boldElements[0].textContent = "Пути перемещения";

        let newSelect = document.createElement('select');
        newSelect.id = 'sl_animation_kind';
        let opt_1 = document.createElement('option');
        let opt_2 = document.createElement('option');
        opt_1.value = 'G';
        opt_1.textContent = 'Буквой «Г»';
        opt_2.value = 'Circle';
        opt_2.textContent = 'По кругу';

        document.getElementById("cx").remove();
        document.getElementById("cy").remove();
        document.getElementById("fx").remove();
        document.getElementById("fy").remove();
        document.querySelector(`label[for='cx']`).remove();
        document.querySelector(`label[for='cy']`).remove();
        document.querySelector(`label[for='fx']`).remove();
        document.querySelector(`label[for='fy']`).remove();

        document.getElementsByTagName('br')[0].parentNode.insertBefore(newSelect, document.getElementsByTagName('br')[0].nextSibling);
        document.getElementById("sl_animation_kind").appendChild(opt_1);
        document.getElementById("sl_animation_kind").appendChild(opt_2);


        boldElements[1].textContent = "";
        boldElements[2].textContent = "";

        document.querySelector(`label[for='cscalex']`).textContent = "";
        document.querySelector(`label[for='cscaley']`).textContent = "";
        document.querySelector(`label[for='fscalex']`).textContent = "";
        document.querySelector(`label[for='fscaley']`).textContent = "";
        document.querySelector(`label[for='crotate']`).textContent = "";
        document.querySelector(`label[for='frotate']`).textContent = "";

        document.getElementById("cscalex").classList.add('hidden');
        document.getElementById("cscaley").classList.add('hidden');
        document.getElementById("fscalex").classList.add('hidden');
        document.getElementById("fscaley").classList.add('hidden');
        document.getElementById("crotate").classList.add('hidden');
        document.getElementById("frotate").classList.add('hidden');
    }
    if (!checkbox.checked) {
        document.getElementById("animation").disabled = false;
        boldElements[0].textContent = "Координаты рисунка";
        document.getElementsByTagName('select')[0].remove();

        let newLabelx1 = addLabel('cx');
        newLabelx1.textContent = 'x: ';
        let newLabely1 = addLabel('cy');
        newLabely1.textContent = 'y: ';
        let newLabelx2 = addLabel('fx');
        let newLabely2 = addLabel('fy');

        let newInputx1 = addInput('number', 'cx', '550', '600', '300');
        let newInputy1 = addInput('number', 'cy', '550', '600', '300');
        let newInputx2 = addInput('number', 'fx', '550', '600', '300');
        let newInputy2 = addInput('number', 'fy', '550', '600', '300');

        document.getElementsByTagName('br')[1].parentNode.insertBefore(newInputy2, document.getElementsByTagName('br')[1].nextSibling);
        document.getElementsByTagName('br')[1].parentNode.insertBefore(newLabely2, document.getElementsByTagName('br')[1].nextSibling);
        document.getElementsByTagName('br')[1].parentNode.insertBefore(newInputy1, document.getElementsByTagName('br')[1].nextSibling);
        document.getElementsByTagName('br')[1].parentNode.insertBefore(newLabely1, document.getElementsByTagName('br')[1].nextSibling);
        document.getElementsByTagName('br')[0].parentNode.insertBefore(newInputx2, document.getElementsByTagName('br')[0].nextSibling);
        document.getElementsByTagName('br')[0].parentNode.insertBefore(newLabelx2, document.getElementsByTagName('br')[0].nextSibling);
        document.getElementsByTagName('br')[0].parentNode.insertBefore(newInputx1, document.getElementsByTagName('br')[0].nextSibling);
        document.getElementsByTagName('br')[0].parentNode.insertBefore(newLabelx1, document.getElementsByTagName('br')[0].nextSibling);


        boldElements[1].textContent = "Масштаб";
        boldElements[2].textContent = "Поворот";

        document.querySelector(`label[for='cscalex']`).textContent = "по x: ";
        document.querySelector(`label[for='cscaley']`).textContent = "по y: ";
        document.querySelector(`label[for='fscalex']`).textContent = " до ";
        document.querySelector(`label[for='fscaley']`).textContent = " до ";
        document.querySelector(`label[for='crotate']`).textContent = "угол: ";
        document.querySelector(`label[for='frotate']`).textContent = " до ";

        document.getElementById("cscalex").classList.remove('hidden');
        document.getElementById("cscaley").classList.remove('hidden');
        document.getElementById("fscalex").classList.remove('hidden');
        document.getElementById("fscaley").classList.remove('hidden');
        document.getElementById("crotate").classList.remove('hidden');
        document.getElementById("frotate").classList.remove('hidden');
    }
}

let animation_change = () => {
    let checkbox = document.getElementById("animation");
    
    if (checkbox.checked) {
        
        let newLabelx = addLabel('fx');
        let newLabely = addLabel('fy');
        let newLabelScalex = addLabel('fscalex');
        let newLabelScaley = addLabel('fscaley');
        let newLabelRotate = addLabel('frotate');

        let newInputx = addInput('number', 'fx', '550', '600', '300');
        let newInputy = addInput('number', 'fy', '550', '600', '300');
        let newInputScalex = addInput('number', 'fscalex', '1.5', '4', '1');
        let newInputScaley = addInput('number', 'fscaley', '1.5', '4', '1');
        let newInputRotate = addInput('number', 'frotate', '180', '360', '0');

        let newButton = addInput('button', 'bt_animation', 'Анимировать');

        let newSelect = document.createElement('select');
        newSelect.id = 'sl_animation';
        let opt_1 = document.createElement('option');
        let opt_2 = document.createElement('option');
        let opt_3 = document.createElement('option');
        opt_1.value = 'linear';
        opt_1.textContent = 'linear';
        opt_2.value = 'elastic';
        opt_2.textContent = 'elastic';
        opt_3.value = 'bounce';
        opt_3.textContent = 'bounce';

        let newLabelCheckBox = document.createElement('label');
        newLabelCheckBox.setAttribute('for', 'cb_animation');
        newLabelCheckBox.textContent = 'Перемещение вдоль путь?';
        let newCheckBox = document.createElement('input');
        newCheckBox.type = 'checkbox';
        newCheckBox.id = 'cb_animation';

        document.getElementById("cx").parentNode.insertBefore(newInputx, document.getElementById("cx").nextSibling);
        document.getElementById("cx").parentNode.insertBefore(newLabelx, document.getElementById("cx").nextSibling);

        document.getElementById("cy").parentNode.insertBefore(newInputy, document.getElementById("cy").nextSibling);
        document.getElementById("cy").parentNode.insertBefore(newLabely, document.getElementById("cy").nextSibling);

        document.getElementById("cscalex").parentNode.insertBefore(newInputScalex, document.getElementById("cscalex").nextSibling);
        document.getElementById("cscalex").parentNode.insertBefore(newLabelScalex, document.getElementById("cscalex").nextSibling);

        document.getElementById("cscaley").parentNode.insertBefore(newInputScaley, document.getElementById("cscaley").nextSibling);
        document.getElementById("cscaley").parentNode.insertBefore(newLabelScaley, document.getElementById("cscaley").nextSibling);

        document.getElementById("crotate").parentNode.insertBefore(newInputRotate, document.getElementById("crotate").nextSibling);
        document.getElementById("crotate").parentNode.insertBefore(newLabelRotate, document.getElementById("crotate").nextSibling);
        
        document.getElementById("anim").parentNode.insertBefore(newSelect, document.getElementById("anim").previousSibling);
        document.getElementById("sl_animation").appendChild(opt_1);
        document.getElementById("sl_animation").appendChild(opt_2);
        document.getElementById("sl_animation").appendChild(opt_3);

        document.getElementById("sl_animation").parentNode.insertBefore(newLabelCheckBox, document.getElementById("sl_animation").nextSibling);
        document.getElementById("sl_animation").parentNode.insertBefore(newCheckBox, document.getElementById("sl_animation").nextSibling);

        let br = document.createElement('br');
        br.id = 'br';
        document.getElementById("sl_animation").parentNode.insertBefore(br, document.getElementById("sl_animation").nextSibling);

        document.getElementById("anim").appendChild(newButton);
        document.getElementById("bt_animation").onclick = function() {
            clear(d3.select("svg")
            .attr("width", 600)
            .attr("height", 600));
            runAnimation(document.getElementById("setting"));
        };
        document.getElementById("cb_animation").onchange = function() {
            kind_animation_change();
        };
    }
    if (!checkbox.checked) {
        let idNewLabelx = document.querySelector(`label[for='fx']`); 
        let idNewInputx = document.getElementById("fx");
        let idNewLabely = document.querySelector(`label[for='fy']`);
        let idNewInputy = document.getElementById("fy");

        let idNewLabelScalex = document.querySelector(`label[for='fscalex']`);
        let idNewInputScalex = document.getElementById("fscalex");
        let idNewLabelScaley = document.querySelector(`label[for='fscaley']`);;
        let idNewInputScaley = document.getElementById("fscaley");

        let idNewLabelRotate = document.querySelector(`label[for='frotate']`);;
        let idNewInputRotate = document.getElementById("frotate");

        idNewInputx.remove();
        idNewLabelx.remove();
        idNewInputy.remove();
        idNewLabely.remove();

        idNewLabelScalex.remove();
        idNewInputScalex.remove();
        idNewLabelScaley.remove();
        idNewInputScaley.remove();

        idNewLabelRotate.remove();
        idNewInputRotate.remove();

        document.getElementById("sl_animation").remove();
        document.querySelector(`label[for='cb_animation']`).remove();
        document.getElementById("cb_animation").remove();
        document.getElementById("br").remove();
        document.getElementById("bt_animation").remove();
    }
}