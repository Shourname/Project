function drawFigure(svg, kindOfFigure, width, height) {
    let figure = svg.append("g")
        .style("stroke", "black")
        .style("stroke-width", 2)
        .style("fill", "white");
    
    if (kindOfFigure == "circle") {
        figure.append("circle") 
        .attr("cx", 0)
        .attr("cy", 0)
        .attr("r", 50);
    }

    if (kindOfFigure == "ellipse") {
        figure.append("ellipse") 
        .attr("cx", 0)
        .attr("cy", 0)
        .attr("rx", 50)
        .attr("ry", 20);
    }

    if (kindOfFigure == "triangle") {
        figure.append("polygon")
        .attr("points", `${0},${0 - 30} ${0 - 25},${0 + 20} ${0 + 25},${0 + 20}`);
    }

    if (kindOfFigure == "rectangle") {
        figure.append("rect")
        .attr("x", 0 - 50)
        .attr("y", 0 - 25)
        .attr("width", 100)
        .attr("height", 50);
    }

    if (kindOfFigure == "square") {
        figure.append("rect")
        .attr("x", 0 - 25)
        .attr("y", 0 - 25)
        .attr("width", 50)
        .attr("height", 50);
    }

    if (kindOfFigure == "pentagon") {
        figure.append("polygon")
            .attr("points", `${0},${0 - 30} ${0 + 30},${0} ${0 + 15},${0 + 25} ${0 - 15},${0 + 25} ${0 - 30},${0}`);
    }

    if (kindOfFigure == "own") {
        figure.append("ellipse") 
        .attr("cx", 0)
        .attr("cy", -60)
        .attr("rx", 30)
        .attr("ry", 90);
        figure.append("ellipse") 
        .attr("cx", 0)
        .attr("cy", -30)
        .attr("rx", 50)
        .attr("ry", 80);
        figure.append("ellipse") 
        .attr("cx", -40)
        .attr("cy", -60)
        .attr("rx", 10)
        .attr("ry", 50);
        figure.append("ellipse") 
        .attr("cx", 40)
        .attr("cy", -60)
        .attr("rx", 10)
        .attr("ry", 50);
        figure.append("circle") 
        .attr("cx", 0)
        .attr("cy", 0)
        .attr("r", 50);
        figure.append("polygon")
            .attr("points", `${0},${0 - 70} ${0 - 25},${0 + 18} ${0 + 25},${0 + 18}`);
        figure.append("circle") 
        .attr("cx", +20)
        .attr("cy", 0)
        .attr("r", 20);
        figure.append("circle") 
        .attr("cx", -20)
        .attr("cy", 0)
        .attr("r", 20);
    }

    return figure;
}
