function createPathEternity() {
    const svg = d3.select("svg");
	const width = svg.attr("width");
	const height = svg.attr("height");
	const centerX = width / 2;
    const centerY = height / 2;
	
	const a = 300;
    let data = [];
	
	// for (let t = 0; t <= Math.PI / 3; t += 0.1) {
	// 	data.unshift({
	// 		x: centerX + (a * ( ((t ** 2) - 1) / ((t ** 2) + 1))),
	// 		y: centerY + (a * ((2 * t * ((t ** 2) - 1)) / ((t ** 2) + 1) ** 2))
	// 	});
	// }
	// for (let t = 0; t <= Math.PI * 2; t += 0.1) {
	// 	data.push({
	// 		x: centerX + (a * ( ((t ** 2) - 1) / ((t ** 2) + 1))),
	// 		y: centerY - (a * ((2 * t * ((t ** 2) - 1)) / ((t ** 2) + 1) ** 2))
	// 	});
	// }
	// for (let t = 0; t <= Math.PI / 3; t += 0.1) {
	// 	data.push({
	// 		x: centerX - (a * ( ((t ** 2) - 1) / ((t ** 2) + 1))),
	// 		y: centerY - (a * ((2 * t * ((t ** 2) - 1)) / ((t ** 2) + 1) ** 2))
	// 	});
	// }

	for (let t = 0; t <= Math.PI*2.1; t += 0.1) {
		data.push({
			x: centerX + a * Math.sin(t),
			y: centerY + a * Math.sin(2*t)
		});
	}

    return data
}

let drawPath =() => {
	const dataPoints = createPathEternity();
	
	const line = d3.line()
		.x((d) => d.x)
		.y((d) => d.y);
    const svg = d3.select("svg")  
	let path = svg.append('path')
		.attr('d', line(dataPoints))
		.attr('stroke', 'black')
		.attr('fill', 'none');

	return path;	
}

function translateAlong(path, dataForm) {
    const length = path.getTotalLength();
	const interpolateScaleX = d3.interpolate(dataForm.cscalex.value, dataForm.fscalex.value);
	const interpolateScaleY = d3.interpolate(dataForm.cscaley.value, dataForm.fscaley.value);
    const interpolateRotate = d3.interpolate(dataForm.crotate.value, dataForm.frotate.value);
    return function() {
        return function(t) {
            const {x, y} = path.getPointAtLength(t * length);
			const scaleX = interpolateScaleX(t);
            const scaleY = interpolateScaleY(t);
            const rotate = interpolateRotate(t);
            return `translate(${x},${y}) scale(${scaleX}, ${scaleY}) rotate(${rotate})`;
        }
    }
}