const width = 800;
const height = 800;

document.addEventListener("DOMContentLoaded", function() {
        
    const svg = d3.select("svg")
       .attr("width", width)
	   .attr("height", height);

    document.getElementById("button_clear").onclick = function() {
        clear(svg);
    };

    document.getElementById("button_animation").onclick = function() {
        clear(svg);
        animate(document.getElementById("setting"));
    };

});

let clear = (svg) => {
    svg.selectAll('*').remove()
};

let animate = (dataForm) => {
    let currentFirure = document.getElementsByTagName('select')[0].value;
    let timeAnimation = document.getElementById("time").value * 1000;

    let svg = d3.select("svg");
    
    let pict = drawFigure(svg, currentFirure, width, height);
    let path = drawPath();

    pict.transition()
        .ease(d3.easeLinear)
        .duration(timeAnimation)
        .attrTween('transform', translateAlong(path.node(), dataForm));
};