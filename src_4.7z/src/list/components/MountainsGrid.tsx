import mountains from "../table"; 
import { DataGrid, GridRowsProp, GridColDef  } from "@mui/x-data-grid";
import { ruRU } from '@mui/x-data-grid/locales';

import Container from '@mui/material/Container';
 
function MountainsGrid() { 
 
    const rows: GridRowsProp = mountains; 
 
    const columns: GridColDef[] = [ 
        { field: 'Название', headerName: 'Название', flex: 1}, 
        { field: 'Страна', flex: 0.5}, 
        { field: 'Абсолютная Высота', flex: 0.5}, 
        { field: 'Относительная Высота', flex: 0.5}, 
        { field: 'Горная Система' }, 
        { field: 'Дата Восхождения'}, 
    ];  
       
    return ( 
 
    <Container maxWidth="lg" sx={{height: '450px', mt: '40px'}}> 
        <DataGrid  
          localeText={ruRU.components.MuiDataGrid.defaultProps.localeText}
          showToolbar={true} 
          rows={rows}  
          columns={columns}  
        /> 
    </Container>  
 
  ); 
} 
 
export default MountainsGrid;