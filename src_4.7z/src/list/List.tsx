import Navbar from "../components/Navbar";
import MountainsGrid from "./components/MountainsGrid";
import Footer from '../components/Footer';

function List() { 
    return ( 
      <div> 
        <Navbar active="2"/>
        <MountainsGrid/>
        <Footer/>
      </div> 
    ); 
} 
   
export default List; 