import Container from '@mui/material/Container'; 
import Box from '@mui/material/Box';

import BuildCard from "./BuildCard";
import structures from "../../data"; 

const cardData = [structures[5], structures[1]];

function Content() { 
  return (
    <Container maxWidth="xl" sx={{ py: 4 }}> 
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {cardData.map((item, index) => (
          <BuildCard 
            key={index} 
            building={item} 
            cardNumber={index + 1}
          /> 
        ))}
      </Box>
    </Container> 
  ); 
} 
 
export default Content; 