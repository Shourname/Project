import React from 'react';
import logo from './images/logo.svg';
import './styles/App.css';

import List from "./list/List"; 

function App() { 
  return ( 
    <> 
      <List/> 
    </> 
  ); 
}

export default App;
