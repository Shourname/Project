import logo from './images/logo.svg';
import './CSS/App.css';
import mountains from './data.js';
import Table from './components/Table.js';

function App() {
  return (
    <div className="App">
       <h3>Самые высокие горы мира</h3>

       <Table data={ mountains } flagPadding={ true } amountRows="10"/>
    </div>
  );
}

export default App;
