import { useState } from 'react';

const Sort = (props) => {

    const { sortParams, setSortParams } = props;

    const [lastDate, setLastDate] = useState(props.currentData);

    const columnHeaders = props.currentData.length > 0 ? Object.keys(props.currentData[0]) : [];

    const getAvailableHeaders = (selectNumber) => {
        const selected = [sortParams.selected1, sortParams.selected2, sortParams.selected3].filter(Boolean);
        return columnHeaders.filter(header => 
            !selected.includes(header) || header === [sortParams.selected1, sortParams.selected2, sortParams.selected3][selectNumber - 1]
        );
    };
    const renderColumnOptions = (selectNumber) => {
        const availableHeaders = getAvailableHeaders(selectNumber);
        const currentSelection = [sortParams.selected1, sortParams.selected2, sortParams.selected3][selectNumber - 1];
        
        return (
            <>
                <option value="">-- Нет --</option>
                {availableHeaders.map((header, index) => (
                    <option key={`select${selectNumber}-${index}`} value={header}>
                        {header}
                    </option>
                ))}
                {currentSelection && !availableHeaders.includes(currentSelection) && (
                    <option value={currentSelection}>{currentSelection}</option>
                )}
            </>
        );
    }
    const handleSelectChange = (selectNumber, value) => {
        const newSortParams = { ...sortParams };
        if (selectNumber === 1) {
            newSortParams.selected2 = '';
            newSortParams.selected3 = '';
            newSortParams.sortOrder2 = false;
            newSortParams.sortOrder3 = false;
        } 
        else if (selectNumber === 2) {
            newSortParams.selected3 = '';
            newSortParams.sortOrder3 = false;
        }
        newSortParams[`selected${selectNumber}`] = value;
        newSortParams[`sortOrder${selectNumber}`] = false;
        props.setSortParams(newSortParams);
    };

    const handleCheckboxChange = (selectNumber, checked) => {
        const newSortParams = { ...sortParams };
        if (selectNumber === 1) {
            newSortParams.sortOrder1 = checked;
        } else if (selectNumber === 2) {
            newSortParams.sortOrder2 = checked;
        } else if (selectNumber === 3) {
            newSortParams.sortOrder3 = checked;
        }
        props.setSortParams(newSortParams);
    };


    const handleSubmit= (event) => {        
        event.preventDefault();
        props.filtering(props.currentData);
    }

    const handleReset = (event) => {
        props.setSortParams({
            selected1: '',
            selected2: '',
            selected3: '',
            sortOrder1: false,
            sortOrder2: false,
            sortOrder3: false,
        });

        props.filtering(lastDate);
        setLastDate(props.fullData);
    }

    return (
        <form style={{textAlign: 'left'}} onSubmit={ handleSubmit } onReset={ handleReset }>
            <p>Сортировать по</p>
            <p>
                <select 
                    value={sortParams.selected1} 
                    onChange={(item) => handleSelectChange(1, item.target.value)}
                >
                    
                    {renderColumnOptions(1)}    
                </select> 
                по убыванию? <input 
                        name="firstSort"  
                        type="checkbox"
                        checked={sortParams.sortOrder1}
                        onChange={(item) => handleCheckboxChange(1, item.target.checked)}
                    />
            </p>
            <p> 
                <select 
                    value={sortParams.selected2} 
                    onChange={(item) => handleSelectChange(2, item.target.value)}
                    disabled={!sortParams.selected1}
                >
                    {renderColumnOptions(2)} 
                </select> 
                по убыванию? <input 
                        name="secondSort" 
                        type="checkbox"
                        checked={sortParams.sortOrder2}
                        onChange={(item) => handleCheckboxChange(2, item.target.checked)}
                    />
            </p>
            <p> 
                <select
                    value={sortParams.selected3} 
                    onChange={(item) => handleSelectChange(3, item.target.value)}
                    disabled={!sortParams.selected2}
                >
                    {renderColumnOptions(3)} 
                </select> 
                по убыванию? <input 
                        name="thirdSort"
                        type="checkbox"
                        checked={sortParams.sortOrder3}
                        onChange={(item) => handleCheckboxChange(3, item.target.checked)}
                    />
            </p>
            <button type="submit">Сортировать</button>   
            <button type="reset">Очистить сортировку</button>
        </form>
    )
}

export default Sort;