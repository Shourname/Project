import TableHead from './TableHead.js';
import TableBody from './TableBody.js';
import Filter from './Filter.js';
import Sort from './Sort.js';
import Chart from './Chart.js';
import { useState, useEffect } from "react";

/*
   компонент, выводящий на страницу таблицу 
   пропсы:
      data - данные для таблицы в виде массива объектов
*/

const Table = (props) => {
    
    const [activePage, setActivePage] = useState("1");
    const [dataTable, setDataTable] = useState(props.data);
    const [sortParams, setSortParams] = useState({
        selected1: '',
        selected2: '',
        selected3: '',
        sortOrder1: false,
        sortOrder2: false,
        sortOrder3: false,
    });

    useEffect(() => {
        setActivePage(1);
    }, [dataTable]);

    const totalPages = Math.ceil(dataTable.length / props.amountRows);
    const handlePageChange = (newPage) => {
        setActivePage(Math.max(1, Math.min(newPage, totalPages)));
    };


    const getComparator = (key, order) => {
        const stringKeys = ["Название", "Страна", "Горная система"];
        const numberKeys = ["Абсолютная Высота", "Относительная Высота"];
        
        return (a, b) => {
            let compareResult = 0;
            const aVal = a[key] || (typeof a[key] === 'number' ? -Infinity : '');
            const bVal = b[key] || (typeof b[key] === 'number' ? -Infinity : '');
    
            if (stringKeys.includes(key)) {
                compareResult = aVal.localeCompare(bVal);
            } else if (numberKeys.includes(key)) {
                const aNum = parseFloat(aVal) || 0;
                const bNum = parseFloat(bVal) || 0;
                compareResult = aNum - bNum;
            } else if (key === "Дата Восхождения") {
                const aDate = new Date(aVal.split('.').reverse().join('.'));
                const bDate = new Date(bVal.split('.').reverse().join('.'));
                compareResult = aDate - bDate;
            }
            
            return order ? -compareResult : compareResult;
        };
    };

    const applySort = (data) => {
        const { selected1, selected2, selected3, sortOrder1, sortOrder2, sortOrder3 } = sortParams;
        const sorters = [];
        if (selected3) sorters.unshift(getComparator(selected3, sortOrder3));
        if (selected2) sorters.unshift(getComparator(selected2, sortOrder2));
        if (selected1) sorters.unshift(getComparator(selected1, sortOrder1));
    
        if (sorters.length === 0) return data;
    
        const sortedData = [...data].sort((a, b) => {
            for (const compareFn of sorters) {
                const result = compareFn(a, b);
                if (result !== 0) return result;
            }
            return 0;
        });
    
        return sortedData;
    };


    const updateDataTable = (newData) => {
        const sortedData = applySort(newData);
        setDataTable(sortedData);
    };
    const getPageNumbers = () => {
        return Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <span
                key={page}
                onClick={() => handlePageChange(page)}
                className={page === activePage ? 'active-number' : 'inactive-number'}>
                {page}
            </span>
        ));
    };

    if (props.flagPadding == false) {
        return (
            <>
                <div className="filters-sorts">
                    <div>
                        <h4>Фильтры</h4>
                        <Filter 
                            filtering={updateDataTable} 
                            fullData={props.data}
                        />   
                    </div>
                    <div>
                        <h4>Сортировка</h4>
                        <Sort
                            filtering={updateDataTable}
                            fullData={props.data}
                            currentData={dataTable}
                            sortParams={sortParams}
                            setSortParams={setSortParams}
                        />
                    </div>
                    <div>
                        <Chart data={ dataTable }/>
                    </div>
                </div>
                
                <table>
                    <TableHead head={Object.keys(props.data[0])} />
                    <TableBody 
                        body={dataTable}
                        amountRows={dataTable.length}
                        numPage={activePage}
                    />
                </table>
            </>
        )
    } else {
        return (
            <>
                <div className="filters-sorts">
                    <div>
                        <h4>Фильтры</h4>
                        <Filter 
                            filtering={updateDataTable} 
                            fullData={props.data}
                        />    
                    </div>
                    <div>
                        <h4>Сортировка</h4>
                        <Sort
                            filtering={updateDataTable}
                            fullData={props.data}
                            currentData={dataTable}
                            sortParams={sortParams}
                            setSortParams={setSortParams}
                        />
                    </div>
                    <div>
                        <Chart data={ dataTable }/>
                    </div>
                </div>

                
                <table>
                    <TableHead head={Object.keys(props.data[0])} />
                    <TableBody 
                        body={dataTable}
                        amountRows={props.amountRows}
                        numPage={activePage}
                    />
                </table>

                {props.flagPadding && totalPages > 1 && (
                    <div className="pages">
                        {getPageNumbers()}
                    </div>
                )}
            </>
        )
    }
}

export default Table;