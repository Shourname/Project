const Filter = (props) => {
  const handleSubmit= (event) => {        
    event.preventDefault();		

    // создаем словарь со значениями полей формы
    
    const filterField = {
      structure: event.target["structure"].value.toLowerCase(),
      country: event.target["country"].value.toLowerCase(),
      mountainSystem: event.target["mountainSystem"].value.toLowerCase(),
      minHeight: event.target["minHeight"].value,
      maxHeight: event.target["maxHeight"].value,
      minDate: event.target["minDate"].value,
      maxDate: event.target["maxDate"].value
    };
    
    let filteredData = props.fullData;
    if (filterField.structure) {
      filteredData = filteredData.filter(item =>
        (item['Название'] || '').toLowerCase().includes(filterField.structure)
      );
    }

    if (filterField.country) {
      filteredData = filteredData.filter(item =>
        (item['Страна'] || '').toLowerCase().includes(filterField.country)
      );
    }

    if (filterField.mountainSystem) {
      filteredData = filteredData.filter(item =>
        (item['Горная Система'] || '').toLowerCase().includes(filterField.mountainSystem)
      );
    }

    // фильтр по высоте

    const minHeight = filterField.minHeight ? Number(filterField.minHeight) : -Infinity;
    const maxHeight = filterField.maxHeight ? Number(filterField.maxHeight) : Infinity;
    filteredData = filteredData.filter(item => {
      const itemHeight = Number(item['Абсолютная Высота']) || 0;
      return itemHeight >= minHeight && itemHeight <= maxHeight;
    });

    // фильтр по дате

    const minDate = filterField.minDate ? new Date(filterField.minDate) : null;
    const maxDate = filterField.maxDate ? new Date(filterField.maxDate) : null;

    filteredData = filteredData.filter(item => {
      const currentDate = item['Дата Восхождения'].split('.').reverse().join('.');
      
      const itemDate = new Date(currentDate);
      
      if (isNaN(itemDate.getTime())) return false;

      const isAfterMin = minDate ? itemDate >= minDate : true;
      const isBeforeMax = maxDate ? itemDate <= maxDate : true;
      
      return isAfterMin && isBeforeMax;
  });

    // передаем родительскому компоненту новое состояние - отфильтрованный массив
    props.filtering(filteredData);
  }

  const handleReset = (event) => {
    props.filtering(props.fullData);
  }
  
  return (
    <form onSubmit={ handleSubmit } onReset={ handleReset }>
      <p>
        <label>Название: </label>
        <input name="structure" type="text" />
      </p>  
      <p>
        <label>Страна: </label>		
        <input name="country" type="text" />
      </p>
      <p>
        <label>Горная система: </label>		
        <input name="mountainSystem" type="text" />
      </p>
      <p>
        <label>Высота от: </label>		
        <input name="minHeight" type="number" />
      </p>
      <p>
        <label>Высота до: </label>		
        <input name="maxHeight" type="number" />
      </p>
      <p>
        <label>Дата восхождения от: </label>		
        <input name="minDate" type="date" />
      </p>
      <p>
        <label>Дата восхождения до: </label>		
        <input name="maxDate" type="date" />
      </p>
      <p>         
        <button type="submit">Фильтровать</button>   
        <button type="reset">Очистить фильтр</button>
      </p>  
    </form> 
  )
}

export default Filter;