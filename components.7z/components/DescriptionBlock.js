const DescriptionBlock = (props) => {
    return (
      <div className="description">
        <p className="welcome-text">{props.text}</p>
        <button className="details-button">
            {props.buttonText}
            <span className="button-arrow">→</span>
        </button>
      </div>
    );
  };
  
  export default DescriptionBlock;