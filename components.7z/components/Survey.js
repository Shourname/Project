import React, { useState } from 'react';

const Survey = (props) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [showError, setShowError] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [answers, setAnswers] = useState([]);

  const handleNextQuestion = () => {
    if (!selectedAnswer) {
      setShowError(true);
      return;
    }
    setAnswers(prev => [...prev, {
      question: props.quiz[currentQuestion].text,
      answer: selectedAnswer
    }]);
    setShowError(false);
    setSelectedAnswer('');
    if (currentQuestion < props.quiz.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setShowResults(true);
    }
  };

  const getResultMessage = () => {
    const firstAnswer = answers[0]?.answer;
    
    if (firstAnswer === 'Да, подобное происходит довольно часто') {
      return "Результаты опроса указывают на явные признаки негативного воздействия. Совпадение ваших ответов с маркерами порчи (частые необъяснимые проблемы, сны с угрожающими символами, ухудшение состояния после контактов) говорит о целенаправленном магическом влиянии. Рекомендуем незамедлительно обратиться к специалисту для диагностики и снятия воздействия.";
    }
    return "Некоторые ваши ответы совпали с признаками влияния темных сил, но картина неоднозначна. Отдельные симптомы (например, редкие странные события или временное ухудшение самочувствия) требуют внимания. Рекомендуем провести очищающие обряды для подстраховки и проявить бдительность к изменениям в жизни.";
  };
  
  return (
    <div className="survey-container" id="test">
      {!showResults ? (
        <>
          <div className="survey-header">
            <h1>{props.textTitle}</h1>
            <hr/><br/>
            <p><b>{props.textDescription}</b></p>
          </div>

          <div className="question-block">
            <h2>{props.quiz[currentQuestion].text}</h2>
            
            <select 
              value={selectedAnswer}
              onChange={(e) => setSelectedAnswer(e.target.value)}
              className="answer-select"
            >
              <option value="">Выберите ответ</option>
              {props.quiz[currentQuestion].answers.map((answer, index) => (
                <option key={index} value={answer}>{answer}</option>
              ))}
            </select>

            {showError && <p className="error-message">Пожалуйста, выберите ответ!</p>}

            <button 
              onClick={handleNextQuestion}
              className="next-button"
            >
              {currentQuestion === props.quiz.length - 1 ? 'Завершить опрос' : 'Следующий вопрос →'}
            </button>
          </div>
        </>
      ) : (
        <div className="result-block">
          <h2>Результаты опроса</h2>
          <div className="results-list">
            <div className="result-item">
              <h3>Вы находитесь под воздействием проклятия!</h3>
              <p>{getResultMessage()}</p>
              <button className="next-button">
                Получить очищение
              </button>
            </div>
          </div>
          
        </div>
      )}
    </div>
  );
};

export default Survey;