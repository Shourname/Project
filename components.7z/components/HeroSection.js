const HeroSection = (props) => {
    return (
      <div className="title-section">
        <h1 className="main-title">{props.title}</h1>
        <p className="subtitle">{props.subtitle}</p>
      </div>
    );
  };
  
  export default HeroSection;