const Navbar = () => {
  return (
    <div className="nav-container">
     <nav className="nav-bar">
      <a href="#main" className="nav-link">ГЛАВНАЯ</a>
      <a href="#test" className="nav-link">ТЕСТИРОВАНИЕ</a>
      <a href="#contacts" className="nav-link">КОНТАКТЫ</a>
     </nav>
    </div>
  );
};

export default Navbar;