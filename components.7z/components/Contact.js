import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa';

const Contact = (props) => {
  return (
    <div className="page-container" id="contacts">
      <div className="content-wrapper">
        <h1 className="main-text">
          Наша энергия и ясновидение действуют на расстоянии, мы можем с вами общаться онлайн при помощи мессенджеров
        </h1>
        <hr/>
        <h3 className="cta-text">
          Свяжитесь с нами, если хотите изменить свою жизнь к лучшему. Наши специалисты обязательно вам помогут.
        </h3>
        <div className="social-icons">
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
          <FaFacebook className="icon" />
        </a>
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
          <FaTwitter className="icon" />
        </a>
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
          <FaInstagram className="icon" />
        </a>
        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
          <FaLinkedin className="icon" />
        </a>
        <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
          <FaYoutube className="icon" />
        </a>
        </div>
      </div>
      <div className="contacts">
        <div className="specialists">{props.contacts}</div>
        <div className="year">{props.year}</div>
      </div>
    </div>
  );
};

export default Contact;