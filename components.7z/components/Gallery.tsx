import ImageList from '@mui/material/ImageList'; 
import ImageListItem from '@mui/material/ImageListItem';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import ImageListItemBar from '@mui/material/ImageListItemBar';
import Typography from '@mui/material/Typography';

import structures from "../data"; 
 
const imgData = structures.slice(0, -1);

function Gallery() { 
    return (
        <Container maxWidth="xl" sx={{ py: 4, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>   
            <Typography 
                variant="h6" 
                align="center" 
                sx={{ 
                    mb: 4, 
                    fontWeight: 'bold',
                    fontSize: { xs: '2rem', sm: '2.5rem', md: '3rem' } 
                }}
            >
                Галерея самых известных гор мира
            </Typography>
            
            <Box sx={{ 
                width: '100%',
                display: 'flex',
                justifyContent: 'center',
                overflowX: 'auto', 
                overflowY: 'hidden',
                py: 2
            }}> 
                <ImageList 
                    variant="standard" 
                    cols={imgData.length}
                    sx={{
                        //display: 'flex',
                        flexWrap: 'nowrap',
                        width: 'auto',
                        minWidth: '100%',
                        transform: 'translateZ(0)',
                        '& .MuiImageList-root': {
                            gridTemplateColumns: `repeat(${imgData.length}, 1fr) !important`
                        },
                        '@media (max-width: 1200px)': {
                            gridTemplateColumns: `repeat(${Math.floor(imgData.length / 2)}, 1fr) !important`
                        },
                        '@media (max-width: 900px)': {
                            gridTemplateColumns: `repeat(${Math.floor(imgData.length / 3)}, 1fr) !important`
                        },
                        '@media (max-width: 600px)': {
                            gridTemplateColumns: `repeat(${Math.floor(imgData.length / 4)}, 1fr) !important`
                        }
                    }}
                    gap={16} 
                > 
                    {imgData.map((item) => ( 
                        <ImageListItem key={ item.img } sx={{ width: 250, height: '100%' }}> 
                            <img 
                                srcSet={ item.img } 
                                src={ item.img } 
                                alt={ item.title } 
                                loading="lazy" 
                                style={{ 
                                    height: 300,
                                    width: '100%',
                                    objectFit: 'cover',
                                    borderRadius: '8px'
                                }}
                            />
                            <ImageListItemBar 
                                position="bottom"
                                title={ item.title } 
                                sx={{ 
                                    borderBottomLeftRadius: '8px',
                                    borderBottomRightRadius: '8px'
                                }}
                            /> 
                        </ImageListItem> 
                    ))} 
                </ImageList>
            </Box>
        </Container>
    ); 
} 
 
export default Gallery;