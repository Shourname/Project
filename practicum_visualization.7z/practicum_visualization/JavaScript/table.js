let showTable = (idTable, data) => {
    let table = d3.select("#" + idTable);
		
	let rows = table
        .selectAll("tr")
		.data(data)
		.enter()
		.append('tr')	
		.style("display", "");

	let cells = rows
        .selectAll("td")
	    .data(d => Object.values(d))
		.enter()
		.append("td")
		.text(d => d);
	  
	let head = table
        .insert("tr", "tr")
		.selectAll("th")
		.data(d => Object.keys(data[0]))
		.enter()
		.append("th")
		.text(d => d);
}

let visibleTable = (idTable, toggleButton) => {
    const dataTable = document.getElementById(idTable);

    if (dataTable.style.display === 'none' || dataTable.style.display === '') {
        dataTable.style.display = 'table';
        toggleButton.value = 'Скрыть таблицу';
    } else {
        dataTable.style.display = 'none';
        toggleButton.value = 'Показать таблицу';
    }
}