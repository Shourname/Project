document.addEventListener("DOMContentLoaded", function() {
    showTable('build', buildings);
    drawGraph(buildings, 'Страна', 1, false, 'point');

    document.getElementById('visibleTable').addEventListener('click', function() {
        visibleTable('build', this);
    });

    document.getElementById('draw').addEventListener('click', function() {
        checkOfDrawing();
    });
});

function checkOfDrawing() {
    let radioValue = document.querySelector('input[name="ox"]:checked').value;
    let checkboxValues = Array.from(document.querySelectorAll('input[name="Height"]:checked')).map(checkbox => checkbox.value);
    let itemTypeGraph = document.getElementById('graph-select').value;
    
    if (checkboxValues.length == 2) drawGraph(buildings, radioValue, 1, true, itemTypeGraph);
    if (checkboxValues.length == 1 && checkboxValues[0] == 'minHeight') drawGraph(buildings, radioValue, 0, false, itemTypeGraph);
    if (checkboxValues.length == 1 && checkboxValues[0] == 'maxHeight') drawGraph(buildings, radioValue, 1, false, itemTypeGraph);
};
