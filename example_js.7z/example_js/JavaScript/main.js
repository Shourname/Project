document.addEventListener("DOMContentLoaded", function() {
    createTable(buildings, 'list');
    setSortSelects(buildings, document.getElementById('sort'));
    drawGraph(buildings, 'Страна', 1, false, 'point');

    document.getElementById('visibleTable').addEventListener('click', function() {
        visibleTable('list', this);
    });
    document.getElementById('draw').addEventListener('click', function() {
        checkOfDrawing();
    });


    document.getElementById("FindFilter").onclick = function() {
        filterTable(buildings, 'list', document.getElementById('filter'));
    };
    document.getElementById("ClearFilter").onclick = function() {
        clearFilter('list', buildings);
    };
    document.getElementById("fieldsFirst").onchange = function() {
        changeNextSelect('fieldsSecond', document.getElementById('fieldsFirst'));
        changeNextSelect('fieldsThird', document.getElementById('fieldsSecond'));
    };
    document.getElementById("fieldsSecond").onchange = function() {
        changeNextSelect('fieldsThird', document.getElementById('fieldsSecond'));
    };
    document.getElementById("SortTable").onclick = function() {
        sortTable('list', document.getElementById('sort'));
    };
    document.getElementById("ClearSort").onclick = function() {
        clearsortTable(document.getElementById('sort'));
    };
})

function checkOfDrawing() {
    let radioValue = document.querySelector('input[name="ox"]:checked').value;
    let checkboxValues = Array.from(document.querySelectorAll('input[name="Height"]:checked')).map(checkbox => checkbox.value);
    let itemTypeGraph = document.getElementById('graph-select').value;

    let table = document.getElementById('list');
    let i = 0;
    let bld = [];

    let headers = [];
    for (let header of table.querySelectorAll('tr th')) {
        headers.push(header.innerText);
    }

    for (let row of table.querySelectorAll('tr')) {
        let rowData = {};
        if (i != 0) {
            let cells = row.querySelectorAll('td');
            
            cells.forEach((cell, index) => {
                if (headers[index] === "Абсолютная Высота" || headers[index] === "Относительная Высота") {
                    rowData[headers[index]] = parseFloat(cell.innerText);
                }else if (headers[index] === "Дата Восхождения") {
                    let dateParts = cell.innerText.split('.');
                    const year = parseInt(dateParts[2], 10);
                    const month = parseInt(dateParts[1], 10) - 1;
                    const day = parseInt(dateParts[0], 10);
                
                    rowData[headers[index]] = new Date(year, month, day);
                } else {
                    rowData[headers[index]] = cell.innerText;
                }
            });
            bld.push(rowData);
        }
        i++;
    }
    
    
    
    if (checkboxValues.length == 2) drawGraph(bld, radioValue, 1, true, itemTypeGraph);
    if (checkboxValues.length == 1 && checkboxValues[0] == 'minHeight') drawGraph(bld, radioValue, 0, false, itemTypeGraph);
    if (checkboxValues.length == 1 && checkboxValues[0] == 'maxHeight') drawGraph(bld, radioValue, 1, false, itemTypeGraph);
};

let visibleTable = (idTable, toggleButton) => {
    const dataTable = document.getElementById(idTable);

    if (dataTable.style.display === 'none' || dataTable.style.display === '') {
        dataTable.style.display = 'table';
        toggleButton.value = 'Скрыть таблицу';
    } else {
        dataTable.style.display = 'none';
        toggleButton.value = 'Показать таблицу';
    }
}


let createOption = (str, val) => {
    let item = document.createElement('option');
    item.text = str;
    item.value = val;
    return item;
}

let setSortSelect = (arr, sortSelect) => {
    
    sortSelect.append(createOption('Нет', 0));
    
    for (let i in arr) {
        sortSelect.append(createOption(arr[i], Number(i) + 1));
    }
}

let setSortSelects = (data, dataForm) => { 

    let head = Object.keys(data[0]); // ошибка
    let allSelect = dataForm.getElementsByTagName('select');
    
    for(let j = 0; j < allSelect.length; j++) {
        setSortSelect(head, allSelect[j]);
        if (j > 0) {
            allSelect[j].disabled = true;
        }
    }
}

let changeNextSelect = (nextSelectId, curSelect) => {
    
    let nextSelect = document.getElementById(nextSelectId);
    
    nextSelect.disabled = false;
    nextSelect.innerHTML = curSelect.innerHTML;
    
    if (curSelect.value != 0) {
       if (nextSelectId == 'fieldsThird') {
            if (curSelect.value != 1) nextSelect.remove(curSelect.value - 1);
            else nextSelect.remove(curSelect.value);
       } else {
            nextSelect.remove(curSelect.value);
       }
    } else {
        nextSelect.disabled = true;
    }
}