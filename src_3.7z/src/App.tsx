import React from 'react';
import logo from './images/logo.svg';
import './styles/App.css';

import Main from "./main/Main";
import List from "./list/List"; 

function App() { 
  return ( 
    <> 
      <List/> 
    </> 
  ); 
}

export default App;
